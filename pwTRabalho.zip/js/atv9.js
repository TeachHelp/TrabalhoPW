

function acordeao1(){
    if (document.querySelector("#sec1").style.display == "none"){
        document.querySelector("#sec1").style.display = "block"
    }
    else{
        document.querySelector("#sec1").style.display = "none"
    }
}

function acordeao2(){
    if (document.querySelector("#sec2").style.display == "none"){
        document.querySelector("#sec2").style.display = "block"
    }
    else{
        document.querySelector("#sec2").style.display = "none"
    }

}

function acordeao3(){
    if (document.querySelector("#sec3").style.display == "none"){
        document.querySelector("#sec3").style.display = "block"
    }
    else{
        document.querySelector("#sec3").style.display = "none"
    }

}

function acordeao4(){
    if (document.querySelector("#sec4").style.display == "none"){
        document.querySelector("#sec4").style.display = "block"
    }
    else{
        document.querySelector("#sec4").style.display = "none"
    }

}